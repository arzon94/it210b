﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

using MySql.Data;
using MySql.Data.MySqlClient;

public partial class _Default : System.Web.UI.Page
{
    private string CONNSTRING = String.Format("uid=it210buser;server={0};port=3306;database=it210b;password=password123;", WebConfigurationManager.AppSettings["dbhost"]);
    protected void Page_Load(object sender, EventArgs e)
    {
        ResultString.Text = String.Empty;
        ResultString.Attributes.Clear();        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            MySqlConnection conn = new MySqlConnection(CONNSTRING);
            conn.Open();
            try
            {
                int userId = Convert.ToInt32(userIdBox.Text);
                string altText = altTextBox.Text;
                string imageUrl = imagePathBox.Text;
                string sql = String.Format("Insert into images (userId,imagePath,altText,imageApproved,numLikes) values ({0},'{1}','{2}',0,0);",userId,imageUrl,altText);

                MySqlCommand command = new MySqlCommand(sql, conn);
                int result = command.ExecuteNonQuery();
                if (result != 1)
                {
                    string errText = @"Error saving values to database";
                    ResultString.Text = errText;
                    ResultString.Attributes.Add("style", "color:red;");
                    throw new Exception(errText);
                }
                else
                {
                    string successText = @"Success!";
                    ResultString.Text = successText;
                    ResultString.Attributes.Add("style", "color:green;");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }

    }
    protected void ResetButton_Click(object sender, EventArgs e)
    {
        ResultString.Text = String.Empty;
        ResultString.Attributes.Clear();

        imagePathBox.Text = String.Empty;
        altTextBox.Text = String.Empty;
        userIdBox.Text = String.Empty;
    }
}